This datasset was generated as MEng group project, the datasets and software script are open
souce protected by the BSD 3-Clause License, Copyright (c) 2023, strathRFM, University of Strathclyde.
for more information please visit: https://github.com/strathRFM/strathRFM

The dataset is in sigMF format and it is also protected by Using Creative Commons Public Licenses, please
also visit: https://github.com/sigmf/SigMF

Contents:

RFSoC_Dataset 	- Consists of two subfolders, where dataset was generated in two locations
	|		in Scotland, and compromises of hourly spectrum data captured in a time 
	|		interval of 6 weeks.
	|
	|_ Troon (situated on the west coast of Ayrshire in Scotland) 910 hrs worth of samples
	|_ Dennistoun (situated on the East end of Glasgow) 1009 hrs worth of samples

RTL-SDR_Dataset 	- consists of various subfolders, each containing at least one sample
			generated using the RTL-SDR device. These samples were generated, 
			to assess if the device is realiable and confronted with the RFSoC
			dataset.